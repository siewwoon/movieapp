import React from 'react';

export default function Comedy () {
    return (
        <>
<h1 className="comedy">Comedy Movie </h1>
        </>
    )
}