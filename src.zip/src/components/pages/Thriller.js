import React from 'react';

export default function Thriller () {
    return (
        <>
<h1 className="thriller">Thriller Movie </h1>
        </>
    )
}