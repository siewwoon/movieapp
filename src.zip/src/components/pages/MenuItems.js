export const MenuItems = [
    {
        title: 'Comedy',
        path: '/comedy',
        cName: 'dropdown-link'
    },

    {
        title: 'Thriller',
        path: '/thriller',
        cName: 'dropdown-link'
    },

    {
        title: 'Cartoon',
        path: '/cartoon',
        cName: 'dropdown-link'
    },

    {
        title: 'Action',
        path: '/action',
        cName: 'dropdown-link'
    }

];