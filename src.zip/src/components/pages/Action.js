import React from 'react';

export default function Consulting () {
    return (
        <>
<h1 className="action">Action Movie </h1>
        </>
    )
}