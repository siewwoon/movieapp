import React from 'react';

export default function ContactUs () {
    return (
        <>
<h1 className="contactUs">Contact Us </h1>
        </>
    )
}