import React from 'react';

export default function SignUp () {
    return (
        <>
<h1 className="signUp">Sign Up </h1>
        </>
    )
}