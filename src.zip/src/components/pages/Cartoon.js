import React from 'react';

export default function Cartoon () {
    return (
        <>
<h1 className="cartoon">Cartoon Movie </h1>
        </>
    )
}