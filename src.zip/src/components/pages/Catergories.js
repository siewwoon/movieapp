import React from 'react';

export default function Catergories () {
    return (
        <>
<h1 className="Categories">Catergories </h1>
        </>
    )
}